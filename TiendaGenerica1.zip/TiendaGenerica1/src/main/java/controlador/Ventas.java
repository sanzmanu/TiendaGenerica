package controlador;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import modelo.ClienteDAO;
import modelo.ClienteDTO;
import modelo.DetalleVentasDAO;
import modelo.DetalleVentasDTO;
import modelo.ProductosDAO;
import modelo.ProductosDTO;
import modelo.VentasDAO;
import modelo.VentasDTO;

/**
 * Servlet implementation class Ventas
 */
@WebServlet("/Ventas")
public class Ventas extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ventas() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		VentasDAO ventDao = new VentasDAO();
		DetalleVentasDAO detvenDao = new DetalleVentasDAO();
		ClienteDAO cliDao = new ClienteDAO();
		ProductosDAO prodDao = new ProductosDAO();

		if (request.getParameter("consultar") != null) {

			int cedula_cliente = Integer.parseInt(request.getParameter("cedula"));
			ClienteDTO cli = cliDao.Buscar_Cliente(cedula_cliente);
			if (cli != null) {
				String nombre;
				cedula_cliente = cli.getCedula_cliente();
				nombre = cli.getNombre_cliente();
				response.sendRedirect("ventas.jsp?cedula=" + cedula_cliente + "&&nombre=" + nombre);
			} else {
				JOptionPane.showMessageDialog(null, "Cliente Inexistente");
				response.sendRedirect("ventas.jsp");
			}
		}

		if (request.getParameter("consultar1") != null) {

			int codigo_producto = Integer.parseInt(request.getParameter("codProd1"));
			ProductosDTO prod = prodDao.Buscar_Producto(codigo_producto);
			if (prod != null) {
				String nombre1;
				codigo_producto = prod.getCodigo_producto();
				nombre1 = prod.getNombre_producto();
				response.sendRedirect("ventas.jsp?codigo1=" + codigo_producto + "&&nombre1=" + nombre1);
				
			} else {
				JOptionPane.showMessageDialog(null, "Producto Inexistente");
				response.sendRedirect("ventas.jsp");
			}
		}

		if (request.getParameter("consultar2") != null) {

			int codigo_producto = Integer.parseInt(request.getParameter("codProd2"));
			ProductosDTO prod = prodDao.Buscar_Producto(codigo_producto);
			if (prod != null) {
				String nombre2;
				codigo_producto = prod.getCodigo_producto();
				nombre2 = prod.getNombre_producto();
				response.sendRedirect("ventas.jsp?codigo2=" + codigo_producto + "&&nombre2=" + nombre2);
			} else {
				JOptionPane.showMessageDialog(null, "Producto Inexistente");
				response.sendRedirect("ventas.jsp");
			}
		}

		if (request.getParameter("consultar3") != null) {

			int codigo_producto = Integer.parseInt(request.getParameter("codProd3"));
			ProductosDTO prod = prodDao.Buscar_Producto(codigo_producto);
			if (prod != null) {
				String nombre3;
				codigo_producto = prod.getCodigo_producto();
				nombre3 = prod.getNombre_producto();
				response.sendRedirect("ventas.jsp?codigo3=" + codigo_producto + "&&nombre3=" + nombre3);
			} else {
				JOptionPane.showMessageDialog(null, "Producto Inexistente");
				response.sendRedirect("ventas.jsp");
			}
		}

		if (request.getParameter("confirmar") != null) {
			
			int cedula_cliente, cedula_usuario, cant1,cant2, cant3;
			double precio1=0, precio2=0, precio3=0,subt1,subt2, subt3,ivaventa, total_venta=0, valor_venta,iva1=0,iva2=0,iva3=0,tot1=0,tot2=0,tot3=0;
			cedula_cliente = Integer.parseInt(request.getParameter("ced"));
			cedula_usuario = Integer.parseInt(request.getParameter("cedUsu"));
			cant1 = Integer.parseInt(request.getParameter("cantidad1"));
			cant2 = Integer.parseInt(request.getParameter("cantidad2"));
			cant3 = Integer.parseInt(request.getParameter("cantidad3"));
			int codigo_producto = Integer.parseInt(request.getParameter("cod1"));
			ProductosDTO prod = prodDao.Buscar_Producto(codigo_producto);
			if (prod != null) {
				precio1 = prod.getPrecio_venta();
			}
			int codigo_producto2 = Integer.parseInt(request.getParameter("cod2"));
			prod = prodDao.Buscar_Producto(codigo_producto2);
			if (prod != null) {
				precio2 = prod.getPrecio_venta();
			}
			int codigo_producto3 = Integer.parseInt(request.getParameter("cod3"));
			prod = prodDao.Buscar_Producto(codigo_producto3);
			if (prod != null) {
				precio3 = prod.getPrecio_venta();
			}
			subt1 = Math.floor((cant1*precio1)+0.5);
			subt2 = Math.floor((cant2*precio2)+0.5);
			subt3 = Math.floor((cant3*precio3)+0.5);
			iva1=Math.floor(((subt1*1.19)-subt1)+0.5);
			iva2=Math.floor(((subt2*1.19)-subt2)+0.5);
			iva3=Math.floor(((subt3*1.19)-subt3)+0.5);
			tot1=subt1+iva1;
			tot2=subt2+iva2;
			tot3=subt3+iva3;
			total_venta =subt1+subt2+subt3;
			ivaventa = Math.floor(((total_venta*1.19)-total_venta)+0.5);
			valor_venta = total_venta+ivaventa;
			VentasDTO vent = new VentasDTO(cedula_cliente, cedula_usuario, ivaventa, total_venta, valor_venta);
			if (ventDao.Inserta_venta(vent)) {
				int codigo=ventDao.BuscarCodVenta();
				DetalleVentasDTO detVent1 = new DetalleVentasDTO(cant1,codigo_producto,codigo,subt1,tot1,iva1);
				DetalleVentasDTO detVent2 = new DetalleVentasDTO(cant2,codigo_producto2,codigo,subt2,tot2,iva2);
				DetalleVentasDTO detVent3 = new DetalleVentasDTO(cant3,codigo_producto3,codigo,subt3,tot3,iva3);
				if(detvenDao.Inserta_detalle_venta(detVent1) && detvenDao.Inserta_detalle_venta(detVent2) && detvenDao.Inserta_detalle_venta(detVent3)) {
					response.sendRedirect("ventas.jsp?cod="+codigo+"&&subt1="+subt1+"&&subt2="+subt2+"&&subt3="+subt3+"&&iva="+ivaventa+"&&subtotal="+total_venta+"&&valorTotal="+valor_venta+
							"&&cant1="+cant1+"&&cant2="+cant2+"&&cant3="+cant3+"&&id="+cedula_usuario+"&&men=venta registrada exitosamente!!");	
				}
			} else {
				response.sendRedirect("ventas.jsp?men=No se registro la venta!!");
			}
		}
		if(request.getParameter("nuevo")!=null) {
			int nuevo=0,id;
			id=Integer.parseInt(request.getParameter("cedUsu"));
			response.sendRedirect("ventas.jsp?nuevo="+nuevo+"&&id="+id);	
		}
	}
}
