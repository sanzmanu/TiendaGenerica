package controlador;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*import javax.swing.JOptionPane;
*/
import modelo.UsuarioDAO;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UsuarioDAO usuDao = new UsuarioDAO();
		
		if(request.getParameter("ingresar")!=null) {
			String usuario,password;
			int id;
			usuario=request.getParameter("usuario");
			password=request.getParameter("clave");
			if(usuDao.Login(usuario,password)) {
				/* JOptionPane.showMessageDialog(null,"Bienvenido!!"); */
				id = usuDao.BuscarId(usuario, password);
				response.sendRedirect("menu.jsp?id="+id +"&&men=BIENVENIDO");
			}else {
				/*
				 * JOptionPane.showMessageDialog(
				 * null,"Usuario o Contrase�a errados, intente de nuevo");
				 */
				response.sendRedirect("login.jsp?men=Usuario o clave errados, intente de nuevo.");
			}
		}
	}
}
