package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import controlador.Conexion;

public class DetalleVentasDAO {

	Conexion cnn = new Conexion();
	Connection conec=cnn.conecta();
	PreparedStatement ps=null;
	ResultSet res=null;
	
	public boolean Inserta_detalle_venta(DetalleVentasDTO detVentas) {
		
		boolean resul = false;
		try {
			String sql = "insert into detalle_ventas (cantidad_producto,codigo_producto,codigo_venta,valor_total,valor_venta,valoriva) values(?,?,?,?,?,?)";
			ps = conec.prepareStatement(sql);
			ps.setInt(1, detVentas.getCantidad_producto());
			ps.setInt(2, detVentas.getCodigo_producto());
			ps.setInt(3, detVentas.getCodigo_venta());
			ps.setDouble(4, detVentas.getValor_total());
			ps.setDouble(5, detVentas.getValor_venta());
			ps.setDouble(6, detVentas.getValoriva());
			resul = ps.executeUpdate() > 0;
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, "Error al insertar detalle de venta" + ex);
		}
		return resul;
	
	}
}
